package core.interfaces;

public interface IGamePhase {}
