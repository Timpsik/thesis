package games.dominion;

public class DominionConstants {

    public enum DeckType {
        HAND, DRAW, DISCARD, TABLE, TRASH, SUPPLY, ALL
    }

    public enum TriggerType {
        StartBuy
    }

}
