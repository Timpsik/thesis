package games.coltexpress.actions.roundcardevents;

import core.actions.AbstractAction;

public abstract class RoundEvent extends AbstractAction {
    public abstract String getEventText();
}
