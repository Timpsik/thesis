package games.catan.components;

public interface Copiable {
    abstract Copiable copy();
}
